
const CACHE="rbf-containers-v3-3";
const STATIC=[
  "./rbf-logo.png","./rbf-banner.png","./icon-192.png","./icon-512.png"
];

self.addEventListener("install",event=>{
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(STATIC)));
});

self.addEventListener("activate",event=>{
  event.waitUntil(
    caches.keys()
      .then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))
      .then(()=>self.clients.claim())
  );
});

self.addEventListener("fetch",event=>{
  if(event.request.method!=="GET") return;
  const url=new URL(event.request.url);

  // Never cache Supabase API calls.
  if(url.pathname.includes("/rest/v1/")) return;

  // Always try the newest HTML/JS/CSS/config from GitHub first.
  if(
    url.pathname.endsWith("/") ||
    /\.(html|js|css|webmanifest)$/i.test(url.pathname)
  ){
    event.respondWith(
      fetch(event.request,{cache:"no-store"})
        .then(response=>response)
        .catch(()=>caches.match(event.request))
    );
    return;
  }

  // Images/icons can be cached.
  event.respondWith(
    caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
      const copy=response.clone();
      caches.open(CACHE).then(cache=>cache.put(event.request,copy));
      return response;
    }))
  );
});
